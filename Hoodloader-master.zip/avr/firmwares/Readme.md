Firmwares
=========

Flash the latest Hoodloader.hex to your Arduino. Install the Hoodloader.inf file then. See main Readme for more informations.

You can ignore the other firmwares.

Arduino-usbserial is the original firmware.

AVRISP_MKII is a Lufa version. Windows driver is in this directory, others wont work!.
The 16u2 version cannot program a mega and might have other bugs! The 32u4 version works on a Leonardo/Micro/Pro Micro! I just left it here.